source ${0:A:h}/zsh-autosuggestions.zsh
